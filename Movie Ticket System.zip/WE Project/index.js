const express = require('express');
const mongoose = require('mongoose');

const app = express();

app.use(express.json());

const PORT = 3000;
const MONGOURL = "mongodb://localhost:27017/MovieTicketReservationSystem";

mongoose.connect(MONGOURL).then(() => {
  console.log("Connected to MongoDB successfully...");
  app.listen(PORT, () => {
    console.log("Server running successfully on port: " + PORT);
  });
}).catch((err) => {
  console.error("Failed to connect to MongoDB:", err);
});

const ticketSchema = new mongoose.Schema({
  _id:Number,
  region: String,
  moviename: String,
  theatre: String,
  showtime: String,
  seattype: String
});

const ticket = mongoose.model("tickets", ticketSchema);

app.get("/", (req, res) => {
  res.send("<h1>Welcome to Movie Ticket Reservation System</h1>");
});

app.get("/getTickets", async (req, res) => {
  try {
    const userData = await ticket.find();
    res.send(userData);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get("/getTickets/:id", async (req, res) => {
    const ids = parseInt(req.params.id);
    try {
      const data = await ticket.findById({ _id: ids });
      if (!data) {
        res.json({ error: 'Ticket not found' });
      }else{
          res.json(data);
      }
    } catch (error) {
      console.error(error);
      res.json({ error: 'Internal server error' });
    }
  });


app.post('/Booktickets', async(req, res) => {
    const data = req.body;
    const newTicket = new ticket(data)
    await newTicket.save()
    res.send("Ticket booked successfully");
})

app.put('/updatetickets/:id', async (req, res) => {
    const id = req.params.id;
    console.log(id);
    const updateTickets = await ticket.findByIdAndUpdate(id, req.body, { new: true });
    if (!updateTickets) {
    res.send(`Ticket booked with id ${id} not found`);
    } else {
        const update = await ticket.findById(id);
        res.send("Ticket updated Successfully");  
    }
  });
  
app.delete('/cancelTicket/:id', async (req, res) => {
    const id = req.params.id;
    const cancelTicket = await ticket.findByIdAndDelete({ _id: id });
    if(!cancelTicket){
        res.send(`cancelled ticket with id ${id} not found`)
    }else{
        res.send("cancelled successfully");
    }
});